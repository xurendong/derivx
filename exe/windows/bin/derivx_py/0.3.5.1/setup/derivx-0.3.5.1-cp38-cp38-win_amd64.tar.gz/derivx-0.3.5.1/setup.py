
# -*- coding: utf-8 -*-

# Copyright (c) 2021-2021 the DerivX authors
# All rights reserved.
#
# The project sponsor and lead author is Xu Rendong.
# E-mail: xrd@ustc.edu, QQ: 277195007, WeChat: ustc_xrd
# See the contributors file for names of other contributors.
#
# Commercial use of this code in source and binary forms is
# governed by a LGPL v3 license. You may get a copy from the
# root directory. Or else you should get a specific written 
# permission from the project author.
#
# Individual and educational use of this code in source and
# binary forms is governed by a 3-clause BSD license. You may
# get a copy from the root directory. Certainly welcome you
# to contribute code of all sorts.
#
# Be sure to retain the above copyright notice and conditions.

from setuptools import setup

readme_text = open("Lib/site-packages/derivx/readme.md", "r", encoding = "utf-8").read()

setup(
    name = "derivx",
    version = "0.3.5.1",
    description = "Derivatives Pricing Engine",
    long_description = readme_text,
    long_description_content_type = "text/markdown",
    author = "Xu Rendong",
    author_email = "xrd@ustc.edu",
    maintainer = "Xu Rendong",
    maintainer_email = "xrd@ustc.edu",
    license = "BSD",
    #packages = ["derivx"],
    #py_modules = ["derivx"],
    data_files = [
        ("Lib/site-packages/derivx", ["Lib/site-packages/derivx/derivx.pyd", 
                                      "Lib/site-packages/derivx/kernel.dll", 
                                      "Lib/site-packages/derivx/__init__.py",  
                                      "Lib/site-packages/derivx/benchmark.md", 
                                      "Lib/site-packages/derivx/changes.txt", 
                                      "Lib/site-packages/derivx/library.txt", 
                                      "Lib/site-packages/derivx/license.txt", 
                                      "Lib/site-packages/derivx/readme.md"])
    ],
    platforms = ["Windows", "Linux", "MacOS", "Unix"],
    python_requires = ">= 3.6",
    install_requires = [],
    keywords = ["options", "futures", "derivatives", "derivatives-pricing", "vanilla", "digital", "barrier", "autocall", "stochastic"],
    url = "https://github.com/xurendong/derivx",
    download_url = "https://pypi.org/project/derivx",
    project_urls = {
        "Source Code": "https://github.com/xurendong/derivx",
        "Bug Tracker": "https://github.com/xurendong/derivx/issues"
    },
    classifiers = [ # https://pypi.python.org/pypi?%3Aaction=list_classifiers
        "Development Status :: 4 - Beta",
        "License :: OSI Approved :: BSD License",
        "Programming Language :: C++",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: JavaScript",
        "Intended Audience :: Education",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Financial and Insurance Industry",
        "Topic :: Office/Business",
        "Topic :: Scientific/Engineering",
        "Operating System :: Unix",
        "Operating System :: MacOS",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Microsoft :: Windows"
    ],
    zip_safe = False
)
